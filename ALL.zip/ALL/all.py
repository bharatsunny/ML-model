
#pickle
 import pickle
    inputFile = open("save1.pkl", 'rb')
    dict2 = pickle.load(inputFile)
    list2 = pickle.load(inputFile)
    inputFile.close()
    print(dict2)
    print(list2)

#tensorflow
import tensorflow as tf
sess=tf.Session() 
export_path =  './savedmodel'
meta_graph_def = tf.saved_model.loader.load(
           sess,
          [tf.saved_model.tag_constants.SERVING],
          export_path)
